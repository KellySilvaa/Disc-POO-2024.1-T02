# Questão 02
Este código Java também calcula a média de notas, mas em vez de uma média ponderada, ele calcula a média aritmética de três notas inseridas pelo usuário. Em seguida, determina o status do aluno, se foi Aprovado, Reprovado ou AF.
