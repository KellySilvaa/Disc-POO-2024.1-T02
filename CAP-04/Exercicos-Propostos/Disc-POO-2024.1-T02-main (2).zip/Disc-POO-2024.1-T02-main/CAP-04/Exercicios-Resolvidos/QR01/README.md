# Questão 01
Este código Java representa um programa simples que calcula a média ponderada de um aluno com base em três notas: uma nota de trabalho de laboratório, uma nota de avaliação semestral e uma nota de exame final. Em seguida, ele determina o conceito obtido pelo aluno com base na média calculada.

Aqui está uma descrição do fluxo do programa:

1. O programa solicita ao usuário que insira a nota do trabalho de laboratório, a nota da avaliação semestral e a nota do exame final.
2. Usando a fórmula da média ponderada ((nota_trab * 2 + aval_sem * 3 + exame * 5) / 10), o programa calcula a média do aluno.
3. Com base na média calculada, o programa determina o conceito do aluno de acordo com as seguintes faixas:
   - Se a média estiver entre 8 e 10, o aluno obteve o conceito A.
   - Se a média estiver entre 7 e menor que 8, o aluno obteve o conceito B.
   - Se a média estiver entre 6 e menor que 7, o aluno obteve o conceito C.
   - Se a média estiver entre 5 e menor que 6, o aluno obteve o conceito D.
   - Se a média estiver entre 0 e menor que 5, o aluno obteve o conceito E.
4. O programa exibe a média ponderada calculada e o conceito obtido pelo aluno.
