# Questão 03
Esse código em Java é um programa simples que solicita ao usuário dois números e, em seguida, determina qual dos números é maior ou se são iguais.

Aqui está uma descrição passo a passo do que o programa faz:

1. O programa importa a classe Scanner para permitir entrada de dados do usuário.
2. Ele declara duas variáveis inteiras, `num1` e `num2`, para armazenar os números fornecidos pelo usuário.
3. O programa solicita que o usuário insira o primeiro número e armazena-o na variável `num1`.
4. Em seguida, solicita ao usuário que insira o segundo número e armazena-o na variável `num2`.
5. O programa verifica se `num1` é maior que `num2`. Se for, imprime que `num1` é o maior número.
6. Se `num2` for maior que `num1`, imprime que `num2` é o maior número.
7. Se ambos os números forem iguais, imprime que são iguais.

Essencialmente, este código determina o maior número entre dois números fornecidos pelo usuário ou informa se eles são iguais.
